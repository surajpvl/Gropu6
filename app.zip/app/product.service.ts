import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private baseUrl = 'http://localhost:8181/food';

  constructor(private http: HttpClient) { }

 
  
  getProducts(): Observable<any> {
    //console.log(this.http.get(`${this.baseUrl}`+'/getAllEmployees'));
    return this.http.get(`${this.baseUrl}`+'/menus');
  }
  getProduct(menu_id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/menus/${menu_id}`);
  }

  createProduct(product: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/menus', product);
  }

  updateProduct(menu_id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/menus/${menu_id}`, value);
  }

  deleteProduct(menu_id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/menus/${menu_id}`, { responseType: 'text' });
  }


   
  isUserLoggedIn() {
    let user = sessionStorage.getItem("username")
    if (user === null) return false
    return true
}

logout() {
  sessionStorage.removeItem("username");
  sessionStorage.setItem("login","failed");
  
}
getLoginStatus()
{
  const loginStatus=sessionStorage.getItem("login");
  return loginStatus;
}
}
