import { Alogin } from './alogin';

describe('Alogin', () => {
  it('should create an instance', () => {
    expect(new Alogin()).toBeTruthy();
  });
});
