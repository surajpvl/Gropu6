export interface Productinfo {
    menu_id:number;
    dish_name:string;
    description:string;
    dish_price:number;
    availablity:string;
    delivery_fee:string;
    curations:string;
   

}