export class Ordercopy {
}

import { Product } from "./product";
import { Productinfo} from "./productcopy";
import { Registerinfo } from "./register";

export class Orderinfo {
    
    order_id: number=0;
    track_no:number=0;
    address:string='';
    quantity:string='';
    upi_id:string='';



    menu_id:number=0;
    dish_name:string="";
    description:string="";
    dish_price:number=0;
    availablity:string="";
    delivery_fee:string="";
    curations:string="";
   
   

    constructor(product:Product) {
 
     this.menu_id=this.menu_id;
     this.dish_name=this.dish_name;
     this.description=this.description;
     this.dish_price=this.dish_price;
     this.availablity=this.availablity;
     this.delivery_fee= this.delivery_fee;
     this.curations=this.curations;

    }
  
    
}



