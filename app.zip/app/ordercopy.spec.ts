import { Ordercopy } from './ordercopy';

describe('Ordercopy', () => {
  it('should create an instance', () => {
    expect(new Ordercopy()).toBeTruthy();
  });
});
