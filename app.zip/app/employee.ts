export class Register {
    user_id:number=0;
    first_name:string="";
    lastname:string="";
    state:string="";
    email_id:string="";
    phone_no:number=0;
    password:string="";
    city:string="";
}