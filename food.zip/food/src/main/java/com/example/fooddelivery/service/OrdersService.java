package com.example.fooddelivery.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddelivery.dao.OrdersRepository;
import com.example.fooddelivery.model.Orders;


@Service
public class OrdersService {

	@Autowired
	OrdersRepository ordRepo;
	
	@Transactional
	public List<Orders> fetchOrder() {
		List<Orders> ordList=ordRepo.findAll();
		return ordList;
	}
	@Transactional 
		  public Orders getOrder(int id) { 
		  Optional<Orders> optional=ordRepo.findById(id);
		  Orders ord=optional.get();
		  return ord;		
	}
	@Transactional
	public Orders saveOrder(Orders order) {		
		return ordRepo.save(order);		
	}
//	@Transactional
//	public void updateOrder(Orders ord) {
//		ordRepo.save(ord);		
//	}
	
	@Transactional
	public void deleteOrder(int ordId) {	
		System.out.println("service method called");
		ordRepo.deleteById(ordId);	
	}
	
}
