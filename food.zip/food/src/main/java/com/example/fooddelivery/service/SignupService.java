package com.example.fooddelivery.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddelivery.dao.SignupRepository;
import com.example.fooddelivery.model.Signup;

@Service
public class SignupService {

	@Autowired
	SignupRepository signRep;
	
	@Transactional
	public List<Signup> fetchRegister() {
		List<Signup> regList=signRep.findAll();
		return regList;
	}
	
	@Transactional 
	  public Signup getUser(int id) { 
	  Optional<Signup> optional=signRep.findById(id);
	  Signup reg=optional.get();
	  return reg;
	  }
	
	@Transactional
	public Signup saveRegister(Signup register) {		
		return signRep.save(register);		
	}
	@Transactional
	public void updateRegister(Signup reg) {
		signRep.save(reg);		
	}
	
	@Transactional
	public void deleteRegister(int regId) {	
		System.out.println("service method called");
		signRep.deleteById(regId);	
	}
	
}
