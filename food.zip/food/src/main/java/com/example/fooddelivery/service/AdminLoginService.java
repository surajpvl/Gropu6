package com.example.fooddelivery.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddelivery.dao.AdminLoginRepository;
import com.example.fooddelivery.model.AdminLogin;

@Service
public class AdminLoginService {

	@Autowired
	AdminLoginRepository adminRepo;

	public AdminLogin validateAdminLogin(AdminLogin adminlogin) {
		AdminLogin al=adminRepo.validateAdminLogin(adminlogin.getEmail_id(),adminlogin.getPassword());
		return al;
	}

	
	
}
