package com.example.fooddelivery.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.fooddelivery.model.Signup;

public interface SignupRepository extends JpaRepository<Signup,Integer> {

}
